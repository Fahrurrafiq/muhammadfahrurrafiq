# Snack Expo (MERN)

FrontEnd :
[https://snack.expo.dev/@alriawi/6?platform=web](https://snack.expo.dev/@aidilmuhammadzaki/pertemuan-6dan7_aidilmuhammadzaki_213510807?authuser=1)https://snack.expo.dev/@aidilmuhammadzaki/pertemuan-6dan7_aidilmuhammadzaki_213510807?authuser=1
 
